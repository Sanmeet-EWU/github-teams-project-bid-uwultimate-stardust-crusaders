# Containers and Orchestration
---

## Containers

### Container 1

```yaml
# Container 1
# Use the official Ubuntu base image
FROM ubuntu:latest

# Update and install necessary packages
RUN apt-get update && apt-get install -y \
    apache2 \
    openssh-server \
    vsftpd \
    && rm -rf /var/lib/apt/lists/*

# Enable FTP anonymous login
RUN sed -i 's/anonymous_enable=NO/anonymous_enable=YES/' /etc/vsftpd.conf

# Expose necessary ports
EXPOSE 80 22 21

# Start the services
CMD service apache2 start && service ssh start && service vsftpd start && tail -f /dev/null
```

### Container 2

```yaml
# Container 2

# Use the official Ubuntu base image
FROM ubuntu:latest

# Update and install necessary packages
RUN apt-get update && apt-get install -y \
    apache2 \
    openssh-server \
    vsftpd \
    && rm -rf /var/lib/apt/lists/*

# Expose necessary ports
EXPOSE 80 22 21

# Start the services
CMD service apache2 start && service ssh start && service vsftpd start && tail -f /dev/null
```

### Container 3

```yaml
# Container 3

# Use the official Ubuntu base image
FROM ubuntu:latest

# Update and install necessary packages
RUN apt-get update && apt-get install -y \
    mysql-server \
    redis-server \
    && rm -rf /var/lib/apt/lists/*

# Expose necessary ports
EXPOSE 3306 6379

# Start the services
CMD service mysql start && service redis-server start && tail -f /dev/null
```

### Container 4

```yaml
# Container 4
# Use the official Ubuntu base image
FROM ubuntu:latest

# Update and install necessary packages
RUN apt-get update && apt-get install -y \
    openssh-server \
    wget \
    && rm -rf /var/lib/apt/lists/*

# Install the most vulnerable version of nginx (nginx 1.4.0 from 2013)
RUN wget http://nginx.org/download/nginx-1.4.0.tar.gz \
    && tar -xzvf nginx-1.4.0.tar.gz \
    && cd nginx-1.4.0 \
    && ./configure \
    && make \
    && make install

# Expose necessary ports
EXPOSE 22 80

# Start the services
CMD service ssh start && /usr/local/nginx/sbin/nginx && tail -f /dev/null
```

### Container 5

```yaml
# Container 5
# Use the official Ubuntu base image
FROM ubuntu:latest

# Update and install necessary packages
RUN apt-get update && apt-get install -y \\
    openssh-server \\
    postgresql \\
    && rm -rf /var/lib/apt/lists/*

# Expose necessary ports
EXPOSE 22 5432

# Start the services
CMD service ssh start && service postgresql start && tail -f /dev/null
```

## Docker Compose Orchestration

```yaml
# docker compose configuration file
version: '3.8'

services:
  CPU1:
    build: ./cpu1
    networks:
      macvlan_network:
        ipv4_address: <IP_here>
    ports:
        - "80:80"
        - "22:22"
        - "21:21"

  CPU2:
    build: ./cpu2
    networks:
      macvlan_network:
        ipv4_address: <IP_here>
    ports:
        - "80:80"
        - "22:22"
        - "21:21"

  CPU3:
    build: ./cpu3
    networks:
      macvlan_network:
        ipv4_address: <IP_here>
    ports:
        - "3306:3306"
        - "6379:6379"

  CPU4:
    build: ./cpu4
    networks:
      macvlan_network:
        ipv4_address: <IP_here>
    ports:
        - "80:80"
        - "22:22"

  CPU5:
    build: ./cpu5
    networks:
      macvlan_network:
        ipv4_address: <IP_here>
    ports:
        - "5432:5432"
        - "22:22"

networks:
  macvlan_network:
    external: true
```
