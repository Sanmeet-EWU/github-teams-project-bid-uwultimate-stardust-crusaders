# README
---

## Getting Started

This deployment is intended for the testing of ScanMaster X. This document will aid in the setup of five 
docker containers that each run a number of services on different ports. This document presumes that 
docker and docker compose are already set up and running on the host machine.

## Project Structure

To ensure that docker compose works correctly, ensure that the project structure is as follows:

```Structure
project-root/
│
├── CPU1/
│   └── Dockerfile
│
├── CPU2/
│   └── Dockerfile
│
├── CPU3/
│   └── Dockerfile
│
├── CPU4/
│   └── Dockerfile
│
├── CPU5/
│   └── Dockerfile
│
└── docker-compose.yml
```

## Macvlan Network

Due to how ScanMaster X works, it is essential that the devices to be scanned are isolated in their own 
environment. A macvlan network ensures this isolation. The following instructions will help set-up of 
a macvlan network.


### Setting Up the Macvlan Network

```bash
docker network create -d macvlan \
  --subnet=<IP_address>/24 \ # subnet according to the host interface IP address
  --gateway=<IP_for_gateway> \
  -o parent=eth0 macvlan_network # replace eth0 with interface
```

### Linking the Macvlan Network to the Host Interface

```shell
# Create macvlan interface for host -> container communication
sudo ip link add macvlan_host link <host_interface_name> type macvlan mode bridge
sudo ip addr add <IP_Address>/24 dev macvlan_host # unique IP address for the macvlan host interface
sudo ip link set macvlan_host up
```

## Starting the Deployment

```bash
docker-compose up --build -d
```

